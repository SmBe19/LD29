package com.smeanox.games.ld29.helper;

public class IntVal {
	public int val;

	public IntVal() {
		val = 0;
	}

	public IntVal(int val) {
		this.val = val;
	}
}
