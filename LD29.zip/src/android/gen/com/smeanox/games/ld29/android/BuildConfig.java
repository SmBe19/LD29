/** Automatically generated file. DO NOT MODIFY */
package com.smeanox.games.ld29.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}